$(document).ready(function() {
  $('.alltime-sort').on('click', function(event) {
    event.preventDefault();
    console.log('javascript working');
  })


});
